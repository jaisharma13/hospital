<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {

        Schema::create('product_stocks', function (Blueprint $table) {

            $table->bigIncrements('id');
            $table->string('patientId');
            $table->string('processId');
            $table->string('activity');
            $table->enum('satackholder', ['Doctor', 'Nurse' ]);
            $table->integer('minutes');
            $table->enum('state', ['Start', 'Process', 'Decision','End']);
            $table->string('nextId');
            $table->timestamps();
        });

    }


    public function down()

    {

        Schema::dropIfExists('product_stocks');

    }

};