<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;


class PostController extends Controller
{
    public function index()
    {

      

        return view('add-blog-post-form');
    }

    public function store(Request $request)
    {

        $data = Post::latest()->limit(1)->get();
  
        $post = new Post;
        $post->title = $request->title;
        $post->description = $request->description;
        // print_r($post);die;

        $post->save();

        // return redirect('patient',compact('data'));
        return view('patient',compact('data'));

    }
}